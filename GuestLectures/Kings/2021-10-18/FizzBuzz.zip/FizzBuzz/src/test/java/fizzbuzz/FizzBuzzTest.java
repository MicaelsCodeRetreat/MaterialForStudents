package fizzbuzz;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class FizzBuzzTest {

	private FizzBuzz fizzBuzz = null;
	
	@Before
	public void setup() {
		fizzBuzz = new FizzBuzz();		
	}
	
	@Test
	public void testOne() {
		int number = 1;
		String expected = "1";
		assertEquals("Expect one to be " + expected, expected, fizzBuzz.evaluate(number));
	}
	@Test
	public void testTwo() {
		String expected = "2";
		assertEquals("Expect two to be " + expected, expected, fizzBuzz.evaluate(2));
	}
	@Test
	public void testThree() {
		String expected = "Fizz";
		assertEquals("Expect three to be " + expected, expected, fizzBuzz.evaluate(3));
	}
	@Test
	public void testFour() {
		String expected = "4";
		assertEquals("Expect four to be " + expected, expected, fizzBuzz.evaluate(4));
	}
	@Test
	@Ignore("Only used to show less than 100% coverage in ECLemma")
	public void testFive() {
		String expected = "Buzz";
		assertEquals("Expect five to be " + expected, expected, fizzBuzz.evaluate(5));
	}
	@Test
	public void testFifteen() {
		String expected = "FizzBuzz";
		assertEquals("Expect fifteen to be " + expected, expected, fizzBuzz.evaluate(15));
	}
}
