package org.micael.tdd.stack;

public class SimpleExampleStack {
	/*
	 * private boolean empty = true;
	 * 
	 * public boolean isEmpty() { return true; // See it fail! } public void
	 * push(int item) { empty = false; // Pushes to void, but that ok. } public int
	 * pop() { int returnValue = 0; return returnValue; }
	 * 
	 */
//	private int stackValue = 0;
	private ExampleListElement topOfStack;

	public boolean isEmpty() {
		return topOfStack == null;
	}

	public void push(int item) {
//	 	stackValue = item;
		ExampleListElement listElement = new ExampleListElement();
		listElement.value = item;
		listElement.nextElement = topOfStack;
		topOfStack = listElement;
	}

	public int pop() {
		int returnValue = 0;
		if (isEmpty()) {
			throw new java.lang.IllegalStateException();
		} else {
			returnValue = topOfStack.value;
			topOfStack = topOfStack.nextElement;
		}
		return returnValue;
	}

	public int top() {
		int returnValue = 0;
		if (isEmpty()) {
			throw new java.lang.IllegalStateException();
		} else {
			returnValue = topOfStack.value;
		}
		return returnValue;
	}

}
