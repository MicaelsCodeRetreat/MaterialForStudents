package org.micael.tdd.stack;

public class ExampleListElement {

	public int value = 0;
	public ExampleListElement nextElement = null;

}
