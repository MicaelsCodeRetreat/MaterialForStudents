package org.micael.tdd.stack;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class SimpleExampleStackTest {
	protected SimpleExampleStack simpleStack;
	
    @Before
    public void setUp() {
    	simpleStack = new SimpleExampleStack();
    }
    
	@Test
	public void testNewStackIsEmpty() {
		boolean empty = simpleStack.isEmpty();
		assertTrue("A newly created stack should be empty!", empty);
	}
	
    @Test
    public void testItemPushOnEmptyStackShouldNotBeEmpty() {
        int item = 10;
        simpleStack.push(item);
        Assert.assertFalse("An empty stack should not be empty after an item has been pushed!", simpleStack.isEmpty());
    }

	@Test
	public void testItemPushOnEmptyStackFollowedByPopShouldReturnItemAndBeEmpty() {
		int pushItem = 10;
		simpleStack.push(pushItem);
		int popItem = simpleStack.pop();
		assertEquals("Poped item should be equal to previously pushed item", pushItem, popItem);
		boolean empty = simpleStack.isEmpty();
		assertTrue("A push on an empty stack followed by a pop should leave an empty stack!", empty);
	}
	
	@Test
	public void testPopFromAnEmptyStackShouldFail() {
		try {
			@SuppressWarnings("unused")
			int popItem = simpleStack.pop();
			fail("Didn't get the expected IllegalStateException here!");
		} catch (IllegalStateException e) {
			// This is expected!
		}
	}
	
    @Test
//    @Ignore ("Not needed...")
    public void testStackPushTwice() {
        int item = 1;
        simpleStack.push(item);
        item = 2;
        simpleStack.push(item);
        Assert.assertFalse("New stack should not be empty after an item has been pushed!", simpleStack.isEmpty());
    }

  	@Test
	public void testPushTwiceFollowedByPopTwiceShouldReturnValuesInReverseOrder() {
		int pushItem1= 10;
		simpleStack.push(pushItem1);
		int pushItem2= 20;
		simpleStack.push(pushItem2);
		int popItem1 = simpleStack.pop();
		assertEquals("First poped item should be equal to last pushed item", pushItem2, popItem1);
		boolean empty = simpleStack.isEmpty();
		assertFalse("Two push on an empty stack followed by one pop should leave one item on stack!", empty);
		int popItem2 = simpleStack.pop();
		assertEquals("Second poped item should be equal to first pushed item", pushItem1, popItem2);
		empty = simpleStack.isEmpty();
		assertTrue("Two push on an empty stack followed by two pop should leave an empty stack!", empty);
	}
	
    @Test
    public void testEmptyStackTop() {
        try {
            @SuppressWarnings("unused")
			int top = simpleStack.top();
            Assert.fail("IllegalStateException expected");
        } catch (java.lang.IllegalStateException e) {
            // Expected
        }
    }

    @Test
    public void testTopOfStackShouldShowPushedItem() {
        int item1 = 1;
        simpleStack.push(item1);
        int topItem = simpleStack.top();
        Assert.assertEquals("Top item was expected to be 1.", item1, topItem);
    }

    @Test
    public void testStackTopTwice() {
        int item1 = 1;
        simpleStack.push(item1);
        int item2 = 2;
        simpleStack.push(item2);
        int topItem = simpleStack.top();
        Assert.assertEquals("Top item was expected to be last pushed item.", item2, topItem);
        topItem = simpleStack.top();
        
        Assert.assertEquals("Top item was expected to be last pushed item.", item2, topItem);
        Assert.assertFalse("Stack should not be empty after stack has been topped!", simpleStack.isEmpty());
    }

}
